import 'package:flutter/material.dart';
import 'package:kulino_coy/list_item.dart';
import 'package:kulino_coy/makanan.dart';
import 'package:kulino_coy/styles.dart';

class MyHomePage extends StatelessWidget {
  const MyHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        children: [
          const SizedBox(height: 20),
          const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(Icons.list_alt_sharp, size: 30),
            Text(
              'List Kuliner',
              style: textHeader1,
            )
          ]),
          Padding(padding: EdgeInsets.only(bottom: 20)),
          Expanded(
            child: ListView.builder(
              itemCount: listMakanan.length,
              padding: const EdgeInsets.all(10),
              itemBuilder: (context, index) {
                return ListItem(
                    nama: listMakanan[index].nama,
                    deskripsi: listMakanan[index].deskripsi,
                    gambar: listMakanan[index].gambar,
                    detail: listMakanan[index].detail,
                    waktubuka: listMakanan[index].waktubuka,
                    harga: listMakanan[index].harga,
                    gambarlain: listMakanan[index].gambarlain,
                    bahan: listMakanan[index].bahan,
                    kalori: listMakanan[index].kalori);
              },
            ),
          )
        ],
      ),
    );
  }
}
