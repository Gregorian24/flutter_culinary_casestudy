package com.example.kulino_coy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
